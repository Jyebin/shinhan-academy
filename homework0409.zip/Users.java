package homework0409;

import lombok.Data;

@Data
public class Users {
    private int userId;
    private String userName;
    private String pw;
    private String birth;
    private String email;
    private String address;
    private int sexCode;
    private String accountNum;
}
