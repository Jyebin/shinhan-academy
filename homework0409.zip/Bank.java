package homework0409;

import lombok.Data;

@Data
public class Bank {
    private int bankId;
    private String bankName;
    private String bankTel;
    private String bankLocation;
    private int accountId;
}
